from setuptools import setup

setup(name='demogorgan_probability',
      version='1.0',
      description='Gaussian distributions',
      packages=['demogorgan_probability'],
      author='Ankit Kumar Prem',
      author_email='ankitkumarprem@gmail.com',
      zip_safe=False)
